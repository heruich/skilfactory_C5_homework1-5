
// Ищем ноду для вставки результата запроса
const resultNode = document.querySelector('.j-result');
// Ищем кнопку, по нажатии на которую будет запрос
const btnNode = document.querySelector('.j-btn-request');

function displayResult() {
    let cards = 'hi';

    const value = document.querySelector('input').value;
    // cards = value;

    const el2 = document.querySelector(".second").value;
    const el1 = document.querySelector(".first").value;

    // cards = el1+el2;
    if ((el1<100 || el1>300)||(el2<100 || el2>300)){
        cards = 'одно из чисел вне диапазоне от 100 до 300';
    }

    if ((el1>=100 && el1<=300)||(el2>=100 && el2<=300)){
        fetch(`https://picsum.photos/${el1}/${el2}`)
            .then((response) => { return response.json(); })
            .then((data) => { console.log(data); })
            .catch(() => { console.log('error') });

        cards = `запрос ушел`

    }


    // cards = el
    resultNode.innerHTML = cards;
}

// Вешаем обработчик на кнопку для запроса
btnNode.addEventListener('click', () => {
     displayResult();
})



