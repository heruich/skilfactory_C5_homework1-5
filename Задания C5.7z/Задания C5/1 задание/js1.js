/* Этап 1. Подготовка данных */

// Создание экземпляра класса DOMParser. Он позволит нам парсить XML
const parser = new DOMParser();
// console.log('parser', parser);

// XML, который мы будем парсить
const xmlString2 = `
  <list>
  <student>
    <name lang="en">
      <first>Ivan</first>
      <second>Ivanov</second>
    </name>
    <age>35</age>
    <prof>teacher</prof>
  </student>
  <student>
    <name lang="ru">
      <first>Петр</first>
      <second>Петров</second>
    </name>
    <age>58</age>
    <prof>driver</prof>
  </student>
  </list>
`;
// console.log('xmlString2', xmlString2);
/* Этап 2. Получение данных */

// Парсинг XML
const xmlDOM2 = parser.parseFromString(xmlString2, "text/xml");
// Получение всех DOM-нод
const listik = xmlDOM2.querySelector("list");
// const listik2 = xmlDOM2.querySelectorAll("list");
const studik = listik.querySelector("student");
// const studik2 = listik2.querySelectorAll("student");
const name = studik.querySelector("name");
const first = name.querySelector("first");
const second = name.querySelector("second");
const age = studik.querySelector("age");
const prof = studik.querySelector("prof");
// console.log('listik2', listik2);
// console.log('studik2', studik2);
// console.log('name', name);
// console.log('age', age);
// console.log('prof', prof);
// console.log('first', first);
// console.log('second', second);
// Получение данных из атрибутов
const langAttr = name.getAttribute('lang');
// console.log('langattr', langAttr);

/* Этап 3. Запись данных в результирующий объект */
const list = {

    name: first.textContent + " " + second.textContent,
    age: Number(age.textContent),
    prof: prof.textContent,
    lang: langAttr,
};
console.log('list', list);

// {
//     list: [
//         { name: 'Ivan Ivanov', age: 35, prof: 'teacher', lang: 'en' },
//         { name: 'Петр Петров', age: 58, prof: 'driver', lang: 'ru' },
//     ]
// }
