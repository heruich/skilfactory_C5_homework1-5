
// Ищем ноду для вставки результата запроса
const resultNode = document.querySelector('.j-result');
// Ищем кнопку, по нажатии на которую будет запрос
const btnNode = document.querySelector('.j-btn-request');

function displayResult() {
    let cards = 'hi';

    const value = document.querySelector('input').value;
    // cards = value;

    if (value > 10 || value <1){
        cards = 'число вне диапазона от 1 до 10';
    }

    if (value >=1 && value <=10){
        // cards = value;
        const xhr = new XMLHttpRequest();

        xhr.onload = function() {
            console.log('Статус: ${xhr.status}; Результат: ${xhr.response}')
        };

        xhr.onerror = function() {
            console.log('Ошибка запроса');
        };

        xhr.open("get", `https://picsum.photos/v2/list?limit=${value}`, true);
        xhr.send();
    }

    resultNode.innerHTML = cards;
}

// Вешаем обработчик на кнопку для запроса
btnNode.addEventListener('click', () => {
     displayResult();
})